import { Router } from "express";
import { requireAuth, AuthedRequest, markAsAdministratorAction } from "../middleware/auth";
import { withRlsContext } from "../db/pool";
import { notificationQueue } from "../jobs/queue";
import { HttpError } from "../utils/httpError";

export const memoriesRouter = Router();

memoriesRouter.post("/memories/:id/react", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const { personId, familyGroupId } = req.auth!;
    const { reactionType } = req.body ?? {};
    if (!reactionType) return res.status(400).json({ error: "reactionType is required" });

    await withRlsContext({ personId, familyGroupId }, (trx) =>
      trx("reactions")
        .insert({ memory_id: req.params.id, person_id: personId, reaction_type: reactionType })
        .onConflict(["memory_id", "person_id", "reaction_type"])
        .ignore()
    );
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

// Worked example of the three-tier deletion policy from docs/data_model.md
// ("Memory deletion policy"). Real business logic, not a stub — this is the
// one endpoint most worth getting exactly right early, since it's where a
// bug would either destroy something meant to be permanent or block a
// legitimate self-delete.
memoriesRouter.delete("/memories/:id", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const { personId, familyGroupId } = req.auth!;
    await withRlsContext({ personId, familyGroupId }, async (trx) => {
      const memory = await trx("memories").where({ id: req.params.id }).first();
      if (!memory) throw new HttpError(404, "Memory not found");
      if (memory.contributor_id !== personId) {
        throw new HttpError(403, "This memory cannot be deleted by anyone other than its original contributor");
      }
      if (memory.provenance_type === "voice") {
        throw new HttpError(403, "Voice-provenance memories cannot be hard-deleted, only retracted");
      }
      if (memory.is_posthumous_contribution) {
        throw new HttpError(403, "Posthumous-profile contributions cannot be self-deleted — they go through moderation instead");
      }
      const [reactionCount, otherPersonLinks] = await Promise.all([
        trx("reactions").where({ memory_id: memory.id }).count().first(),
        trx("memory_persons").where({ memory_id: memory.id }).whereNot({ person_id: personId }).first(),
      ]);
      if (Number(reactionCount?.count ?? 0) > 0 || otherPersonLinks) {
        throw new HttpError(409, "This memory is linked or reacted to — use retract instead of delete");
      }
      await trx("memories").where({ id: memory.id }).del(); // the DB trigger is the real backstop, this check is the friendly error path
    });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

// Soft-hides a linked/reacted (or voice, or simply preferred) memory. Contributor only.
// Notifies anyone who reacted to it — see docs/data_model.md's three-tier policy,
// tier 2. Posthumous contributions are excluded here too: those only ever move
// through the flags/moderation path (tier 3), never a unilateral contributor action.
memoriesRouter.post("/memories/:id/retract", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const { personId, familyGroupId } = req.auth!;
    await withRlsContext({ personId, familyGroupId }, async (trx) => {
      const memory = await trx("memories").where({ id: req.params.id }).first();
      if (!memory) throw new HttpError(404, "Memory not found");
      if (memory.contributor_id !== personId) {
        throw new HttpError(403, "This memory cannot be retracted by anyone other than its original contributor");
      }
      if (memory.is_posthumous_contribution) {
        throw new HttpError(403, "Posthumous-profile contributions cannot be self-retracted — they go through moderation instead");
      }
      if (memory.retracted) {
        throw new HttpError(409, "This memory has already been retracted");
      }

      const reactors = await trx("reactions").where({ memory_id: memory.id }).distinct("person_id");
      await trx("memories").where({ id: memory.id }).update({ retracted: true, retracted_at: new Date() });

      await Promise.all(
        reactors.map((r: { person_id: string }) =>
          notificationQueue.add("memory-retracted", {
            recipientPersonId: r.person_id,
            type: "memory_retracted",
            payload: { memoryId: memory.id },
          })
        )
      );
    });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

// Administrator-only: notifies the original contributor that a restore has
// been requested. Does NOT flip `retracted` itself — only the contributor's
// own POST /restore can do that (enforced by the route below, and backstopped
// by the memory_retraction_self_only RLS policy).
memoriesRouter.post(
  "/memories/:id/restore-request",
  requireAuth,
  markAsAdministratorAction,
  async (req: AuthedRequest, res, next) => {
    try {
      const { personId, familyGroupId } = req.auth!;
      await withRlsContext(
        { personId, familyGroupId, actingAsAdministrator: true },
        async (trx) => {
          const memory = await trx("memories").where({ id: req.params.id }).first();
          if (!memory) throw new HttpError(404, "Memory not found");
          if (!memory.retracted) throw new HttpError(409, "This memory is not retracted, so there is nothing to restore");

          await notificationQueue.add("memory-restore-requested", {
            recipientPersonId: memory.contributor_id,
            type: "memory_restore_requested",
            payload: { memoryId: memory.id, requestedBy: personId },
          });
        }
      );
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  }
);

// Contributor only — reverses a retraction. Administrators cannot call this
// directly; they can only ask via restore-request above.
memoriesRouter.post("/memories/:id/restore", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const { personId, familyGroupId } = req.auth!;
    await withRlsContext({ personId, familyGroupId }, async (trx) => {
      const memory = await trx("memories").where({ id: req.params.id }).first();
      if (!memory) throw new HttpError(404, "Memory not found");
      if (memory.contributor_id !== personId) {
        throw new HttpError(403, "This memory cannot be restored by anyone other than its original contributor");
      }
      if (!memory.retracted) throw new HttpError(409, "This memory is not retracted, so there is nothing to restore");

      await trx("memories").where({ id: memory.id }).update({ retracted: false, retracted_at: null });
    });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
