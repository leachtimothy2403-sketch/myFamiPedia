import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    testTimeout: 20_000, // pglite boot + WASM init is slower than a real Postgres connection
    hookTimeout: 20_000,
    // Each file boots its own pglite instance on its own randomly-assigned
    // port (get-port), so they don't contend with each other — parallel is
    // safe and keeps the full suite under the sandbox's per-call time limit.
  },
});
